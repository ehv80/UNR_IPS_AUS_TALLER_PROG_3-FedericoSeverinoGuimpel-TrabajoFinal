import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimpleServlet extends HttpServlet {

	/** * Maneja el m�todo GET de HTPP para construir una sencilla p�gina Web. */ 
	public void doGet (HttpServletRequest request, HttpServletResponse response)throws IOException 
		{
			PrintWriter out; 
			String title = "Simple Servlet Output"; 
			// primero selecciona el tipo de contenidos y otros campos de cabecera de la 
			// respuesta 
			response.setContentType("text/html"); 
			// Luego escribe los datos de la respuesta 
			out = response.getWriter();
			out.println("<HTML><HEAD><TITLE>");
			out.println(title);
			out.println("</TITLE></HEAD><BODY>");
			out.println("<H1>" + title + "</H1>");
			out.println("<P>This is output from SimpleServlet.");
			out.println("</BODY></HTML>"); 
			out.close(); 

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
